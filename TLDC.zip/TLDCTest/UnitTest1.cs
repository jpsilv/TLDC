﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TLDC;
using System.Collections.Generic;

namespace TLDCTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestProcessString()
        {
            StringProcessor sp = new StringProcessor();
            // Test null and empty collection
            // Expected result
            List<string> expectedResult = new List<string>();
            expectedResult.Add("ERROR 1");
            var result = sp.processString(null);
            Assert.AreEqual(result, expectedResult);

            List<string> inputStrings = new List<string>();
            result = sp.processString(inputStrings);
            Assert.AreEqual(result, expectedResult);

            // Test empty string
            expectedResult.Clear();
            expectedResult.Add("ERROR 2");
            inputStrings.Add("");
            result = sp.processString(inputStrings);
            Assert.AreEqual(result, expectedResult);

            // Test all chars removed
            expectedResult.Clear();
            expectedResult.Add("ERROR 3");
            inputStrings.Clear();
            inputStrings.Add("______444444");
            result = sp.processString(inputStrings);
            Assert.AreEqual(result, expectedResult);

            // Test for successfull result
            expectedResult.Clear();
            inputStrings.Clear();
            expectedResult.Add("Ac91%cWwWkLq£1c");
            inputStrings.Add("AAAc91%cWwWkLq$1ci3_848v3d__K");
            result = sp.processString(inputStrings);
            Assert.AreEqual(result, expectedResult);




        }
    }
}
