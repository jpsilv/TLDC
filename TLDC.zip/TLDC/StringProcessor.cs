﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TLDC
{
    public class StringProcessor
    {
        public List<string> processString(List<string> collection)
        {
            List<string> collectionToReturn = new List<string>();

            if (collection == null || collection.Count == 0)
            {
                collectionToReturn.Add("ERROR 1");
                return collectionToReturn;
            }

            foreach (string str in collection)
            {
                if (str == null || str.Length == 0)
                {
                    // To maintain the characters under 15 I'll just return error instead of the actual error.
                    collectionToReturn.Add("ERROR 2");
                    continue;
                }

                string replacedStr = str.Replace("4", "").Replace("_", "").Replace("$", "£");
                // if string gets empty after removing all the chars I'll return other error
                // not really sure of what I should do in this cases
                if (replacedStr.Length == 0)
                {
                    collectionToReturn.Add("ERROR 3");
                    continue;
                }

                char previousChar = '\0';
                string outputStr = "";

                foreach (char c in replacedStr)
                {
                    if (previousChar == '\0')
                    {
                        previousChar = c;
                        continue;
                    }
                    if (previousChar != c)
                    {
                        outputStr += previousChar;
                        previousChar = c;
                    }
                }
                // Add the last char to the string
                outputStr += previousChar;
                collectionToReturn.Add(outputStr.Substring(0, outputStr.Length > 15 ? 15 : outputStr.Length));

            }

            return collectionToReturn;
        }
    }
}
