﻿using System;
using System.Collections.Generic;

namespace TLDC
{
    class Program
    {
        static void Main(string[] args)
        {
            // setup an initial collection
            List<string> inputParameter = new List<string>();
            inputParameter.Add("AAAc91%cWwWkLq$1ci3_848v3d__K");
            inputParameter.Add("LLLFASDasdasdwa___ççç###$$$$%");
            inputParameter.Add("FFSADW$$$%%%&&////####4445555");
            inputParameter.Add("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
            inputParameter.Add("_____");
            inputParameter.Add("");
            inputParameter.Add(null);
            StringProcessor sp = new StringProcessor();
            List<string> result = sp.processString(inputParameter);

            // print input collection
            Console.WriteLine("Input collection:" + Environment.NewLine);
            foreach (string input in inputParameter)
            {
                Console.WriteLine(input);
            }

            // print results
            Console.WriteLine(Environment.NewLine + "Results:" + Environment.NewLine);
            foreach (string str in result)
            {
                Console.WriteLine(str);
            }
            Console.WriteLine(Environment.NewLine + "Press enter to exit...");
            Console.Read();
        }

        
    }
}
